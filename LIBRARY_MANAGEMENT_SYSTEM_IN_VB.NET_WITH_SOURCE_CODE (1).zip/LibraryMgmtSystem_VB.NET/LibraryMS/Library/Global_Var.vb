﻿Module Global_Var



    Public Connect As String = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = " & Application.StartupPath & "\Library.accdb"
    Public AddEdit As Integer = 0
    Public AdvncSrch As Integer = 0

    Public NofBooksCopies As Integer = 13
    Public NoofBooks As Integer = 5
    Public bookCount As Integer = 0
End Module
